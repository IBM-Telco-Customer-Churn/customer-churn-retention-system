"""
Churn API for the Random Forest trained on the IBM-extended Telco dataset
(City, Age, CLTV, Offer, ...). Input fields use the SAME names as the training columns.

Run:  uvicorn main_rf:app --reload
"""

import logging
import os
from contextlib import asynccontextmanager
from typing import Literal

import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, ConfigDict, Field

MODEL_PATH = os.getenv("MODEL_PATH", "rf_model.joblib")
SCALER_PATH = os.getenv("SCALER_PATH", "scaler.joblib")
FEATURE_COLUMNS_PATH = os.getenv("FEATURE_COLUMNS_PATH", "feature_columns.joblib")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("churn-api")

# Columns that were label-encoded to a single 0/1 column in training.
# ASSUMPTION: Yes->1, No->0, Male->1, Female->0. Verify against your notebook.
BINARY_COLS = {
    "Gender", "Under 30", "Senior Citizen", "Married", "Dependents", "Referred a Friend",
    "Phone Service", "Multiple Lines", "Internet Service", "Online Security", "Online Backup",
    "Device Protection Plan", "Premium Tech Support", "Streaming TV", "Streaming Movies",
    "Streaming Music", "Unlimited Data", "Paperless Billing",
}
BINARY_MAP = {"Yes": 1, "No": 0, "Male": 1, "Female": 0}

# One-hot encoded in training (first category dropped, so it maps to all zeros).
CATEGORICAL_COLS = {"City", "Offer", "Internet Type", "Contract", "Payment Method"}

YesNo = Literal["Yes", "No"]


class CustomerData(BaseModel):
    """Fields are named exactly like the training columns (use the aliases in JSON)."""

    model_config = ConfigDict(populate_by_name=True, extra="forbid")

    gender: Literal["Male", "Female"] = Field(alias="Gender")
    age: int = Field(alias="Age", ge=18, le=120)
    under_30: YesNo = Field(alias="Under 30")
    senior_citizen: YesNo = Field(alias="Senior Citizen")
    married: YesNo = Field(alias="Married")
    dependents: YesNo = Field(alias="Dependents")
    number_of_dependents: int = Field(0, alias="Number of Dependents", ge=0)
    city: str = Field(alias="City")
    population: int = Field(alias="Population", ge=0)
    referred_a_friend: YesNo = Field(alias="Referred a Friend")
    number_of_referrals: int = Field(0, alias="Number of Referrals", ge=0)
    offer: Literal["None", "Offer A", "Offer B", "Offer C", "Offer D", "Offer E"] = Field(alias="Offer")
    tenure_in_months: int = Field(alias="Tenure in Months", ge=0, le=120)
    phone_service: YesNo = Field(alias="Phone Service")
    avg_monthly_long_distance_charges: float = Field(alias="Avg Monthly Long Distance Charges", ge=0)
    multiple_lines: YesNo = Field(alias="Multiple Lines")
    internet_service: YesNo = Field(alias="Internet Service")
    internet_type: Literal["None", "Cable", "DSL", "Fiber Optic"] = Field(alias="Internet Type")
    avg_monthly_gb_download: float = Field(alias="Avg Monthly GB Download", ge=0)
    online_security: YesNo = Field(alias="Online Security")
    online_backup: YesNo = Field(alias="Online Backup")
    device_protection_plan: YesNo = Field(alias="Device Protection Plan")
    premium_tech_support: YesNo = Field(alias="Premium Tech Support")
    streaming_tv: YesNo = Field(alias="Streaming TV")
    streaming_movies: YesNo = Field(alias="Streaming Movies")
    streaming_music: YesNo = Field(alias="Streaming Music")
    unlimited_data: YesNo = Field(alias="Unlimited Data")
    contract: Literal["Month-to-Month", "One Year", "Two Year"] = Field(alias="Contract")
    paperless_billing: YesNo = Field(alias="Paperless Billing")
    payment_method: Literal["Bank Withdrawal", "Credit Card", "Mailed Check"] = Field(alias="Payment Method")
    monthly_charge: float = Field(alias="Monthly Charge", ge=0)
    total_charges: float = Field(alias="Total Charges", ge=0)
    total_refunds: float = Field(0, alias="Total Refunds", ge=0)
    total_extra_data_charges: float = Field(0, alias="Total Extra Data Charges", ge=0)
    total_long_distance_charges: float = Field(alias="Total Long Distance Charges", ge=0)
    total_revenue: float = Field(alias="Total Revenue", ge=0)
    cltv: int = Field(alias="CLTV", ge=0)


@asynccontextmanager
async def lifespan(app: FastAPI):
    app.state.model = joblib.load(MODEL_PATH)
    app.state.scaler = joblib.load(SCALER_PATH)
    app.state.cols = list(joblib.load(FEATURE_COLUMNS_PATH))
    n = getattr(app.state.scaler, "n_features_in_", None)
    if n is not None and n != len(app.state.cols):
        raise RuntimeError(f"Scaler expects {n} features but feature_columns has {len(app.state.cols)}")
    logger.info("Loaded model + scaler + %d feature columns", len(app.state.cols))
    yield


app = FastAPI(title="Random Forest Churn Prediction API", lifespan=lifespan)


def preprocess(customer: CustomerData, cols: list, scaler) -> pd.DataFrame:
    row = pd.DataFrame(0.0, index=[0], columns=cols)
    unmatched = []

    for name, value in customer.model_dump(by_alias=True).items():
        if name in BINARY_COLS:
            row.at[0, name] = BINARY_MAP[value]
        elif name in CATEGORICAL_COLS:
            dummy = f"{name}_{value}"
            if dummy in row.columns:
                row.at[0, dummy] = 1.0
            elif name == "City":
                unmatched.append(dummy)      # city unseen in training
            # else: reference category (dropped with drop_first) -> stays 0
        elif name in row.columns:
            row.at[0, name] = value
        else:
            unmatched.append(name)

    if unmatched:
        logger.warning("Values with no matching training column: %s", unmatched)

    # Same scaling as training (scaler was fitted on the full feature frame).
    return pd.DataFrame(scaler.transform(row.values), columns=cols)


@app.get("/")
def home():
    return {"message": "Random Forest Churn API is running!"}


@app.post("/predict")
def predict_churn(data: CustomerData):
    try:
        X = preprocess(data, app.state.cols, app.state.scaler)
        pred = int(app.state.model.predict(X.values)[0])
        proba = float(app.state.model.predict_proba(X.values)[0][1])
    except Exception:
        logger.exception("Prediction failed")
        raise HTTPException(status_code=500, detail="Prediction failed due to an internal error.")
    return {"Churn_Prediction": "Yes" if pred == 1 else "No", "Churn_Probability": round(proba, 2)}